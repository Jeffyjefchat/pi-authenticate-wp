<?php
/**
 * Plugin Name: Pi Auth – All-in-One (Simple) v2
 * Description: Minimal Pi Network authentication for WP with heavy debug + content gating. Shortcodes: [pi_login_v2], [pi_gate]...[/pi_gate], [pi_lock sel="#commentform,.your-selector"]
 * Version: 2.1.2
 * Author: ChatGPT
 */

if (!defined('ABSPATH')) { exit; }

class PIAIO_SimpleV2 {
  const REST_NS = 'pi-auth/v1';
  const REST_LOGIN = 'login';

  public function __construct() {
    add_action('init', [$this, 'init']);
    add_action('wp_enqueue_scripts', [$this, 'enqueue']);
    add_filter('body_class', [$this, 'body_class']);
    add_action('rest_api_init', [$this, 'rest']);
    add_shortcode('pi_login_v2', [$this, 'sc_login']);
    add_shortcode('pi_gate', [$this, 'sc_gate']);
    add_shortcode('pi_lock', [$this, 'sc_lock']);
  }

  public function init() {
    // nothing yet
  }

  public function is_authed_user() {
    $uid = get_current_user_id();
    if (!$uid) return false;
    // Consider any logged-in user as authenticated for gating (since login requires Pi auth via this plugin's route)
    return true;
  }

  public function enqueue() {
    $ver = '2.1.2';
    wp_register_script('piaio-js', plugins_url('assets/pi-auth.js', __FILE__), [], $ver, true);

    $sandbox = null;
    // Allow constant to force sandbox (optional)
    if (defined('PIAIO_SANDBOX')) {
      $sandbox = (bool) PIAIO_SANDBOX;
    }

    $locks = get_option('piaio_locks', []); // not used, but placeholder if extended later

    wp_localize_script('piaio-js', 'PI_AUTH_CFG', [
      'rest'    => esc_url_raw( rest_url(self::REST_NS . '/' . self::REST_LOGIN) ),
      'nonce'   => wp_create_nonce('wp_rest'),
      'version' => '2.0',
      'sandbox' => $sandbox, // null means auto-detect
      'debug'   => true,
      'locks'   => [], // per-page locks will be injected by shortcode
    ]);

    wp_enqueue_script('piaio-js');
    // Style: tiny chip + hidden gate
    wp_add_inline_style('wp-block-library', '.piaio-chip{display:inline-flex;gap:.5rem;align-items:center;background:#eee;border-radius:999px;padding:.25rem .5rem;font-size:.875rem}.piaio-gate.piaio-locked>.piaio-inner{display:none}.piaio-notice{background:#fff3cd;border:1px solid #ffeeba;padding:.75rem;border-radius:.5rem;margin:.5rem 0}.piaio-hide{display:none!important}');

    // expose authed state
    wp_add_inline_script('piaio-js', 'window.PIAIO_PREAUTH = ' . json_encode($this->is_authed_user()) . ';', 'before');
  }

  public function body_class($classes) {
    $classes[] = $this->is_authed_user() ? 'piaio-user' : 'piaio-guest';
    return $classes;
  }

  public function rest() {
    register_rest_route(self::REST_NS, '/' . self::REST_LOGIN, [
      'methods'  => 'POST',
      'permission_callback' => '__return_true',
      'callback' => [$this, 'rest_login'],
    ]);
  }

  public function rest_login($req) {
    // Access token & user from JS
    $body = json_decode($req->get_body(), true);
    if (!$body || empty($body['accessToken']) || empty($body['user']) || empty($body['user']['uid']) ) {
      return new WP_REST_Response(['ok'=>false,'error'=>'invalid_payload'], 400);
    }

    $pi_uid  = sanitize_text_field($body['user']['uid']);
    $pi_name = isset($body['user']['username']) ? sanitize_user($body['user']['username']) : 'piuser_' . wp_generate_password(6, false);

    // Find or create a WP user mapped to this Pi UID
    $user_id = $this->find_user_by_pi_uid($pi_uid);
    if (!$user_id) {
      // create
      $login = $this->unique_login_from($pi_name);
      $password = wp_generate_password(24, true, true);
      $user_id = wp_insert_user([
        'user_login' => $login,
        'user_pass'  => $password,
        'display_name' => $pi_name,
        'user_nicename'=> sanitize_title($pi_name),
      ]);
      if (is_wp_error($user_id)) {
        return new WP_REST_Response(['ok'=>false,'error'=>'user_create_failed','msg'=>$user_id->get_error_message()], 500);
      }
      update_user_meta($user_id, 'pi_uid', $pi_uid);
    }

    // Log in
    wp_set_current_user($user_id);
    wp_set_auth_cookie($user_id, true);
    do_action('wp_login', get_userdata($user_id)->user_login, get_userdata($user_id));

    return new WP_REST_Response([
      'ok'=>true,
      'user'=>[
        'id'=>$user_id,
        'login'=>get_userdata($user_id)->user_login,
        'display'=>get_userdata($user_id)->display_name,
      ]
    ], 200);
  }

  private function find_user_by_pi_uid($pi_uid) {
    global $wpdb;
    $uid = $wpdb->get_var($wpdb->prepare("SELECT user_id FROM {$wpdb->usermeta} WHERE meta_key='pi_uid' AND meta_value=%s LIMIT 1", $pi_uid));
    return $uid ? intval($uid) : 0;
  }

  private function unique_login_from($base) {
    $login = $base;
    $i = 1;
    while (username_exists($login)) {
      $i++;
      $login = $base . $i;
    }
    return $login;
  }

  public function sc_login($atts, $content='') {
    $label = isset($atts['label']) ? sanitize_text_field($atts['label']) : 'Login with Pi';
    $html  = '<button class="piaio-login" data-rest="'. esc_attr( rest_url(self::REST_NS . '/' . self::REST_LOGIN) ) .'">'. esc_html($label) .'</button>';
    $html .= '<span class="piaio-chip piaio-hide"></span>';
    return $html;
  }

  public function sc_gate($atts, $content='') {
    if ($this->is_authed_user()) {
      return do_shortcode($content);
    }
    $btn = do_shortcode('[pi_login_v2 label="Login with Pi"]');
    $notice = '<div class="piaio-notice">Authentication required.</div>';
    return '<div class="piaio-gate piaio-locked"><div class="piaio-inner">'. do_shortcode($content) .'</div>'. $notice . $btn .'</div>';
  }

  public function sc_lock($atts) {
    $sel = isset($atts['sel']) ? esc_attr($atts['sel']) : '';
    if (!$sel) return '';
    // inject selector list into JS config (per page)
    $script = "<script>window.PI_AUTH_CFG = window.PI_AUTH_CFG||{}; (PI_AUTH_CFG.locks=PI_AUTH_CFG.locks||[]).push(...'". addslashes(json_encode(array_map('trim', explode(',', $sel)))) ."'.split(','));</script>";
    // add a visible placeholder
    $btn  = do_shortcode('[pi_login_v2 label="Login with Pi"]');
    $html = '<div class="piaio-notice piaio-lock-note">Authentication required to view this section.</div>'.$btn;
    return $script . ($this->is_authed_user() ? '' : $html);
  }
}

new PIAIO_SimpleV2();
