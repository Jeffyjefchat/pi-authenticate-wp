(function(){
  const log = (...a)=>{ try { console.log('[PiAIO]', ...a); } catch(e){} };
  const once = (fn)=>{ let ran=false; return (...a)=>{ if(!ran){ ran=true; try{fn(...a);}catch(e){}} }; };
  const state = { authed: !!window.PIAIO_PREAUTH, user:null, sdkReady:false, sandbox:null };

  function inferSandbox() {
    if (typeof window.PI_AUTH_CFG !== 'object') window.PI_AUTH_CFG = {};
    if (typeof PI_AUTH_CFG.sandbox === 'boolean') return PI_AUTH_CFG.sandbox;
    // meta tag <meta name="pi:sandbox" content="true|false">
    const m = document.querySelector('meta[name="pi:sandbox"]');
    if (m && m.content) return m.content === 'true';
    // referer origin
    try {
      const ref = document.referrer || '';
      if (ref.indexOf('sandbox.minepi.com') !== -1) return true;
      if (ref.indexOf('minepi.com') !== -1) return false;
    } catch(e){}
    // default to production unless domain contains 'sandbox'
    return /sandbox/.test(location.hostname);
  }

  function ensureSDK(cb){
    if (window.Pi && typeof window.Pi.init === 'function') return cb();
    const s = document.createElement('script');
    s.src = 'https://sdk.minepi.com/pi-sdk.js';
    s.onload = cb;
    s.onerror = ()=>log('failed to load Pi SDK');
    document.head.appendChild(s);
  }

  function initSDK(){
    state.sandbox = inferSandbox();
    log('env:auto { sandbox:', state.sandbox, ' }');
    ensureSDK(()=>{
      try{
        window.Pi.init({ version: (PI_AUTH_CFG.version||'2.0'), sandbox: state.sandbox });
        state.sdkReady = true;
        log('sdk:init { sandbox:', state.sandbox, ' }');
      }catch(e){
        log('sdk:init error', e);
      }
    });
  }

  function showChip(user){
    const chip = document.querySelector('.piaio-chip');
    if (!chip) return;
    chip.classList.remove('piaio-hide');
    chip.textContent = 'Logged in as ' + (user?.username || user?.display || user?.login || 'Pi User');
  }

  function lockSelectors(authed){
    const locks = (window.PI_AUTH_CFG && Array.isArray(PI_AUTH_CFG.locks)) ? PI_AUTH_CFG.locks : [];
    if (!locks.length) return;
    locks.forEach(sel=>{
      try{
        document.querySelectorAll(sel).forEach(el=>{
          if (authed) {
            el.classList.remove('piaio-hide');
            el.querySelectorAll('input,textarea,button,select').forEach(c=>c.disabled=false);
          } else {
            el.classList.add('piaio-hide');
            el.querySelectorAll('input,textarea,button,select').forEach(c=>c.disabled=true);
          }
        });
      }catch(e){ log('lockSelectors error', e); }
    });
  }

  function openGates(){
    document.querySelectorAll('.piaio-gate').forEach(g=>g.classList.remove('piaio-locked'));
  }

  function authFlow(){
    document.addEventListener('click', async (ev)=>{
      const btn = ev.target.closest('.piaio-login');
      if (!btn) return;
      ev.preventDefault();
      if (!state.sdkReady) return log('SDK not ready');
      try{
        const scopes = ['username'];
        const auth = await window.Pi.authenticate(scopes, function onIncompletePaymentFound(){ /* no payments here */ });
        log('auth_ok ...');
        state.authed = true;
        state.user = auth.user || null;
        showChip(auth.user);
        // server login
        const res = await fetch(btn.dataset.rest || (PI_AUTH_CFG && PI_AUTH_CFG.rest), {
          method: 'POST',
          headers: { 'Content-Type':'application/json', 'X-WP-Nonce': (PI_AUTH_CFG && PI_AUTH_CFG.nonce) || '' },
          body: JSON.stringify({ accessToken: auth.accessToken, user: auth.user })
        });
        let data = {}; try { data = await res.json(); } catch(e){}
        if (!res.ok || !data.ok) { log('server login failed', data); }
        // Unlock UI
        openGates();
        lockSelectors(true);
        window.dispatchEvent(new CustomEvent('piaio:auth', { detail: { authed:true, user:auth.user } }));
      }catch(err){
        log('auth_error', err);
      }
    }, { once:false, passive:false });

    // Apply initial locks for guests
    if (!state.authed) lockSelectors(false);
  }

  // Boot
  document.addEventListener('DOMContentLoaded', ()=>{
    initSDK();
    authFlow();
    if (state.authed) { openGates(); lockSelectors(true); }
  });
})();
