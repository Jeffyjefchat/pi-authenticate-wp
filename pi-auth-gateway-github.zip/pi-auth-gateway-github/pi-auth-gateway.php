<?php
/**
 * Plugin Name: Pi Auth Gateway
 * Description: Pi login/auth for WordPress. Auto-auth inside Pi Browser (username-only by default). Shortcode [pi_login scopes="username,payments"] for pages that need payments.
 * Version: 0.3.4
 * Author: nodegeist + assistant
 */

if ( ! defined('ABSPATH') ) exit;

class Pi_Auth_Gateway {
  const OPT_KEY = 'pi_auth_gateway_options';
  const NONCE   = 'pi_auth_gateway_nonce';

  public function __construct(){
    add_action('admin_menu', [$this,'menu']);
    add_action('admin_init', [$this,'register_settings']);
    add_action('admin_post_pi_auth_gateway_save', [$this,'save_settings']);
    add_shortcode('pi_login', [$this,'shortcode_login']);
    add_action('rest_api_init', [$this,'rest_routes']);
    add_action('wp_enqueue_scripts', [$this,'register_assets']);
    add_action('init', [$this,'hooks_snippets']); // defer until pluggables ready
  }

  public function menu(){
    add_menu_page('Pi Auth Gateway','Pi Auth','manage_options','pi-auth-gateway',[$this,'settings_page'],'dashicons-admin-network',58);
  }

  public function register_settings(){
    register_setting(self::OPT_KEY, self::OPT_KEY, [ $this, 'sanitize_options' ]);
  }

  public function default_options(){
    return [
      'pi_app_id'       => '',
      'pi_api_key'      => '',
      'environment'     => 'sandbox', // sandbox|production
      'app_bearer'      => '',
      'cf_client_id'    => '',
      'cf_client_secret'=> '',
      'gateway_base'    => '',
      'allowed_origins' => site_url(),
      'load_pi_sdk_globally' => 1,
      'auto_auth_all_pages'  => 1,
      'header_snippet'  => '<script src="https://sdk.minepi.com/pi-sdk.js"></script>',
      'footer_snippet'  => '',
    ];
  }

  public function get_options(){
    $opts = get_option(self::OPT_KEY, []);
    return wp_parse_args($opts, $this->default_options());
  }

  public function sanitize_options($input){
    $out = $this->get_options();
    $out['pi_app_id']        = sanitize_text_field($input['pi_app_id'] ?? '');
    $out['pi_api_key']       = sanitize_text_field($input['pi_api_key'] ?? '');
    $out['environment']      = in_array(($input['environment'] ?? ''),['sandbox','production'],true) ? $input['environment'] : 'sandbox';
    $out['app_bearer']       = sanitize_text_field($input['app_bearer'] ?? '');
    $out['cf_client_id']     = sanitize_text_field($input['cf_client_id'] ?? '');
    $out['cf_client_secret'] = sanitize_text_field($input['cf_client_secret'] ?? '');
    $out['gateway_base']     = esc_url_raw($input['gateway_base'] ?? '');
    $out['allowed_origins']  = sanitize_text_field($input['allowed_origins'] ?? '');
    $out['load_pi_sdk_globally'] = isset($input['load_pi_sdk_globally']) ? 1 : 0;
    $out['auto_auth_all_pages']  = isset($input['auto_auth_all_pages']) ? 1 : 0;
    $out['header_snippet']   = isset($input['header_snippet']) ? wp_kses_post($input['header_snippet']) : '';
    $out['footer_snippet']   = isset($input['footer_snippet']) ? wp_kses_post($input['footer_snippet']) : '';
    return $out;
  }

  public function settings_page(){
    if( ! current_user_can('manage_options') ) return;
    $opts = $this->get_options(); ?>
    <div class="wrap">
      <h1>Pi Auth Gateway</h1>
      <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
        <?php wp_nonce_field(self::NONCE); ?>
        <input type="hidden" name="action" value="pi_auth_gateway_save" />
        <table class="form-table" role="presentation">
          <tr><th><label>Pi App ID</label></th><td><input class="regular-text" type="text" name="pi_auth_gateway_options[pi_app_id]" value="<?php echo esc_attr($opts['pi_app_id']); ?>"></td></tr>
          <tr><th><label>Pi API Key</label></th><td><input class="regular-text" type="password" name="pi_auth_gateway_options[pi_api_key]" value="<?php echo esc_attr($opts['pi_api_key']); ?>"></td></tr>
          <tr><th><label>Environment</label></th><td><select name="pi_auth_gateway_options[environment]">
            <option value="sandbox" <?php selected('sandbox',$opts['environment']); ?>>Sandbox</option>
            <option value="production" <?php selected('production',$opts['environment']); ?>>Production</option>
          </select></td></tr>
          <tr><th><label>App Bearer Token</label></th><td><input class="regular-text" type="password" name="pi_auth_gateway_options[app_bearer]" value="<?php echo esc_attr($opts['app_bearer']); ?>"></td></tr>
          <tr><th><label>Allowed Origins (comma)</label></th><td><input class="regular-text" type="text" name="pi_auth_gateway_options[allowed_origins]" value="<?php echo esc_attr($opts['allowed_origins']); ?>"></td></tr>
          <tr><th>Load Pi SDK Globally</th><td><label><input type="checkbox" name="pi_auth_gateway_options[load_pi_sdk_globally]" value="1" <?php checked(1,(int)$opts['load_pi_sdk_globally']); ?>> Add Pi SDK tag to all pages</label></td></tr>
          <tr><th>Auto-auth on all pages</th><td><label><input type="checkbox" name="pi_auth_gateway_options[auto_auth_all_pages]" value="1" <?php checked(1,(int)$opts['auto_auth_all_pages']); ?>> Inside Pi Browser: auto sign-in (username only)</label></td></tr>
          <tr><th><label>Header snippet (&lt;head&gt;)</label></th><td><textarea class="large-text code" rows="6" name="pi_auth_gateway_options[header_snippet]"><?php echo esc_textarea($opts['header_snippet']); ?></textarea></td></tr>
          <tr><th><label>Footer snippet (before &lt;/body&gt;)</label></th><td><textarea class="large-text code" rows="6" name="pi_auth_gateway_options[footer_snippet]"><?php echo esc_textarea($opts['footer_snippet']); ?></textarea></td></tr>
        </table>
        <?php submit_button('Save Settings'); ?>
      </form>
      <hr/>
      <p>Use <code>[pi_login scopes="username"]</code> almost everywhere. On payment pages, use <code>[pi_login scopes="username,payments"]</code>.</p>
    </div>
  <?php }

  public function save_settings(){
    if( ! current_user_can('manage_options') ) wp_die('Forbidden');
    check_admin_referer(self::NONCE);
    $input = $_POST['pi_auth_gateway_options'] ?? [];
    update_option(self::OPT_KEY, $this->sanitize_options($input));
    wp_safe_redirect(admin_url('admin.php?page=pi-auth-gateway&saved=1'));
    exit;
  }

  public function register_assets(){
    wp_register_script('pi-auth-inline','',[],null,true);
  }

  public function hooks_snippets(){
    $opts = $this->get_options();
    $allow = [
      'script' => [ 'src'=>[], 'defer'=>[], 'async'=>[], 'type'=>[], 'crossorigin'=>[], 'referrerpolicy'=>[] ],
      'link'   => [ 'rel'=>[], 'href'=>[], 'as'=>[], 'crossorigin'=>[] ],
      'meta'   => [ 'name'=>[], 'content'=>[], 'http-equiv'=>[], 'charset'=>[] ],
      'style'  => [ 'type'=>[] ],
    ];
    add_action('wp_head', function() use ($opts,$allow){
      if( !empty($opts['load_pi_sdk_globally']) ){
        echo '<script src="https://sdk.minepi.com/pi-sdk.js"></script>' . "\n";
      }
      if( !empty($opts['header_snippet']) ){
        echo wp_kses( $opts['header_snippet'], $allow ) . "\n";
      }
    }, 1);

    add_action('wp_footer', function() use ($opts,$allow){
      $envFlag = ($opts['environment']==='production') ? 'false' : 'true';
      $loginEp = esc_js( rest_url('pi-auth/v1/login') );
      $nonce   = esc_js( wp_create_nonce('wp_rest') );
      $bearer  = esc_js( trim($opts['app_bearer']) );
?>
<script>
(function(){
  // Run only in Pi Browser and only once
  if(!/PiBrowser/i.test(navigator.userAgent)) return;
  if(window.__PI_GATEWAY_INIT__) return; window.__PI_GATEWAY_INIT__ = true;

  // Force deterministic sandbox default; URL ?sandbox=1 overrides
  window.PI_ENV = window.PI_ENV || {};
  PI_ENV.sandboxDefault = <?php echo $envFlag; ?>;

  function ensureSDK(cb){
    if(window.Pi){ cb(); return; }
    var s=document.createElement('script'); s.src='https://sdk.minepi.com/pi-sdk.js';
    s.onload=cb; document.head.appendChild(s);
  }
  function computeSandbox(){
    var d = !!PI_ENV.sandboxDefault;
    var p = new URLSearchParams(location.search), ov = p.get('sandbox');
    return (ov===null) ? d : (ov==='1'||ov==='true');
  }
  function initPi(){
    try{ Pi.init({version:'2.0', sandbox: computeSandbox()}); }catch(e){}
  }
  function autoAuth(){
    if(!<?php echo (int)$opts['auto_auth_all_pages']; ?>) return;
    if(document.cookie.indexOf('wordpress_logged_in_') !== -1) return;
    if(sessionStorage.getItem('pi_auto_auth_done')) return;
    var scopes=['username']; // username-only by default
    Pi.authenticate(scopes,{appName:document.title,appIcon:''}).then(function(res){
      sessionStorage.setItem('pi_auto_auth_done','1');
      var payload={ uid:res.user&&res.user.uid, username:res.user&&res.user.username, accessToken:res.accessToken, env: computeSandbox() ? 'sandbox' : 'production' };
      return fetch('<?php echo $loginEp; ?>',{
        method:'POST',
        headers:{
          'Content-Type':'application/json',
          'X-WP-Nonce':'<?php echo $nonce; ?>'<?php echo $bearer ? ", 'Authorization':'Bearer ".$bearer."'" : ""; ?>
        },
        credentials:'same-origin',
        body: JSON.stringify(payload)
      });
    }).then(function(r){return r?r.json():null}).then(function(){ try{ location.reload(); }catch(e){} })
      .catch(function(e){ console.warn('Pi auto-auth skipped:', (e&&e.message)||e); });
  }
  ensureSDK(function(){ initPi(); document.addEventListener('DOMContentLoaded', autoAuth); });
})();
</script>
<?php
      if( !empty($opts['footer_snippet']) ){
        echo wp_kses( $opts['footer_snippet'], $allow ) . "\n";
      }
    }, 99);
  }

  public function shortcode_login($atts){
    $opts  = $this->get_options();
    $attrs = shortcode_atts([
      'label'        => 'Login with Pi',
      'scopes'       => 'username,payments', // override per page
      'force_sandbox'=> '',                  // '1' to force sandbox here
      'class'        => '',
    ], $atts, 'pi_login');

    $nonce   = wp_create_nonce('wp_rest');
    $rest    = esc_url_raw( rest_url('pi-auth/v1/login') );
    $bearer  = trim($opts['app_bearer']);
    $env     = ($opts['environment'] === 'production') ? 'production' : 'sandbox';
    $scopes  = array_filter(array_map('trim', explode(',', $attrs['scopes'])));
    $scopes  = $scopes ? $scopes : ['username'];
    $forceSb = $attrs['force_sandbox'] === '1';

    ob_start(); ?>
<style>.pi-env-badge{display:inline-block;margin-left:8px;padding:2px 8px;border-radius:9999px;font-size:12px;line-height:18px;color:#fff;background:#0ea5e9;vertical-align:middle}.pi-login-wrap{display:inline-flex;align-items:center;gap:.5rem;flex-wrap:wrap}.pi-help{font-size:12px;opacity:.8}</style>
<div class="pi-login-wrap">
  <button type="button" class="button button-primary <?php echo esc_attr($attrs['class']); ?>" id="pi-login-btn"><?php echo esc_html($attrs['label']); ?></button>
  <span id="pi-env-badge" class="pi-env-badge" aria-live="polite">…</span>
  <div id="pi-login-status" class="pi-help"></div>
</div>
<script>
(function(){
  if (!('__PI_GATEWAY_INIT__' in window)) window.__PI_GATEWAY_INIT__ = false;

  const btn = document.getElementById('pi-login-btn');
  const badge = document.getElementById('pi-env-badge');
  const statusEl = document.getElementById('pi-login-status');
  const REST_URL = <?php echo wp_json_encode($rest); ?>;
  const WP_NONCE = <?php echo wp_json_encode($nonce); ?>;
  const APP_BEARER = <?php echo wp_json_encode($bearer); ?>;
  const ENV_DEFAULT = <?php echo wp_json_encode($env); ?>;
  const FORCE_SB = <?php echo $forceSb ? 'true' : 'false'; ?>;
  const SCOPES = <?php echo wp_json_encode(array_values($scopes)); ?>;

  function inPiBrowser(){ return /PiBrowser/i.test(navigator.userAgent); }
  function computeSandbox(){
    if (FORCE_SB) return true;
    const u = new URL(location.href);
    if (u.searchParams.has('sandbox')) { const v=u.searchParams.get('sandbox'); return (v==='1'||v==='true'); }
    return (ENV_DEFAULT !== 'production');
  }
  function setBadge(sb){ if(!badge) return; badge.textContent = sb ? 'SANDBOX' : 'PRODUCTION'; badge.style.background = sb ? '#0ea5e9' : '#16a34a'; }
  function ensureSDK(){ if(window.Pi) return Promise.resolve(window.Pi); return new Promise((res,rej)=>{ const s=document.createElement('script'); s.src='https://sdk.minepi.com/pi-sdk.js'; s.onload=()=>res(window.Pi); s.onerror=()=>rej(new Error('Pi SDK failed')); document.head.appendChild(s); }); }

  async function doLogin(){
    statusEl.textContent='';
    if(!inPiBrowser()){ statusEl.innerHTML='Open this page in <b>Pi Browser</b> to continue.'; return; }
    try{
      const PiObj = await ensureSDK();
      const sb = computeSandbox(); setBadge(sb);
      if(!window.__PI_GATEWAY_INIT__){ try{ PiObj.init({version:'2.0', sandbox: sb}); }catch(e){} window.__PI_GATEWAY_INIT__ = true; }
      statusEl.textContent='Requesting Pi authentication…';
      const authRes = await PiObj.authenticate(SCOPES, { appName: document.title || 'WP Site', appIcon: '' });
      statusEl.textContent='Verifying with WordPress…';
      const payload = { uid: authRes?.user?.uid, username: authRes?.user?.username, accessToken: authRes?.accessToken, env: sb ? 'sandbox' : 'production' };
      const headers = { 'Content-Type':'application/json', 'X-WP-Nonce': WP_NONCE };
      if (APP_BEARER) headers['Authorization'] = 'Bearer ' + APP_BEARER;
      const res = await fetch(REST_URL, { method:'POST', headers, credentials:'same-origin', body: JSON.stringify(payload) });
      const data = await res.json().catch(()=>({}));
      if(!res.ok) throw new Error((data && data.message) || 'Login failed');
      statusEl.textContent='Logged in — reloading…'; try{ location.reload(); }catch(e){}
    }catch(e){ statusEl.textContent='Error: ' + (e && e.message ? e.message : e); }
  }

  setBadge( computeSandbox() );
  btn && btn.addEventListener('click', doLogin);
})();
</script>
<?php
    return ob_get_clean();
  }

  public function rest_routes(){
    register_rest_route('pi-auth/v1','/login', [
      'methods' => 'POST',
      'callback'=> [$this,'rest_login'],
      'permission_callback' => function(){ return true; },
    ]);
  }

  private function origin_allowed($opts){
    if ( empty($_SERVER['HTTP_ORIGIN']) ) return true; // same-origin
    $allowed = array_map('trim', explode(',', (string)$opts['allowed_origins']));
    return in_array($_SERVER['HTTP_ORIGIN'], $allowed, true);
  }

  public function rest_login(\WP_REST_Request $req){
    $opts = $this->get_options();
    if ( ! $this->origin_allowed($opts) ) {
      return new \WP_Error('forbidden_origin','Origin not allowed', ['status'=>403]);
    }
    $body = $req->get_json_params();
    $uid   = sanitize_text_field($body['uid'] ?? '');
    $usern = sanitize_text_field($body['username'] ?? '');
    $token = sanitize_text_field($body['accessToken'] ?? '');
    $env   = ($body['env'] ?? 'sandbox') === 'production' ? 'production' : 'sandbox';
    if( empty($uid) || empty($usern) || empty($token) ){
      return new \WP_Error('bad_request','Missing fields from Pi auth', ['status'=>400]);
    }
    $appBearer = trim($opts['app_bearer']);
    $authHeader = $req->get_header('authorization');
    if ( $appBearer !== '' ){
      if ( empty($authHeader) || ! hash_equals('Bearer '.$appBearer, $authHeader) ){
        return new \WP_Error('unauthorized','Invalid app bearer', ['status'=>401]);
      }
    }
    // NOTE: You should validate $token with Pi Platform API in production.

    $login = 'pi_' . strtolower(preg_replace('/[^a-z0-9_\-]/i','', $usern ?: $uid));
    $email = $login . '@pi.local';
    $user_id = username_exists($login);
    if( ! $user_id ){
      $user_id = wp_create_user($login, wp_generate_password(24), $email);
      if ( is_wp_error($user_id) ){
        return new \WP_Error('user_create_failed', $user_id->get_error_message(), ['status'=>500]);
      }
      wp_update_user(['ID'=>$user_id, 'display_name'=>$usern]);
    }
    wp_set_current_user($user_id);
    wp_set_auth_cookie($user_id, true);
    return new \WP_REST_Response(['ok'=>true,'user'=>['ID'=>$user_id,'user_login'=>$login,'display_name'=>get_the_author_meta('display_name',$user_id)]], 200);
  }
}

new Pi_Auth_Gateway();
