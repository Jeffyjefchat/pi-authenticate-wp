<?php
/**
 * Plugin Name: Pi Auth – All-in-One (Simple) v2
 * Description: Minimal Pi Network authentication for WP with heavy debug + content gating. Shortcodes: [pi_login_v2], [pi_gate]...[/pi_gate], [pi_lock sel="#selector1,#selector2"]
 * Version: 2.3.0
 * Author: ChatGPT
 */

if (!defined('ABSPATH')) { exit; }

class PIAIO_SimpleV2 {
  const VERSION = '2.3.0';
  const OPT_KEY = 'piaio_settings_v2';
  const REST_NS = 'pi-auth/v1';
  const REST_LOGIN = 'login';

  public function __construct() {
    add_action('init', [$this, 'init']);
    add_action('wp_enqueue_scripts', [$this, 'enqueue']);
    add_filter('body_class', [$this, 'body_class']);
    add_action('rest_api_init', [$this, 'rest']);

    add_shortcode('pi_login_v2', [$this, 'sc_login']);
    add_shortcode('pi_gate', [$this, 'sc_gate']);
    add_shortcode('pi_lock', [$this, 'sc_lock']);

    // Admin
    add_action('admin_menu', [$this, 'admin_menu']);
    add_action('admin_init', [$this, 'admin_register']);
  }

  public function init() {}

  // ---------- Settings ----------
  public static function get_settings() {
    $defaults = ['env'=>'auto','debug'=>0];
    $opts = get_option(self::OPT_KEY, []);
    return wp_parse_args($opts, $defaults);
  }

  public function admin_menu() {
    add_menu_page('Pi Auth', 'Pi Auth', 'manage_options', 'piaio-settings', [$this, 'admin_page'], 'dashicons-shield', 81);
  }

  public function admin_register() {
    register_setting('piaio_group', self::OPT_KEY);
    add_settings_section('piaio_main', 'Pi Auth Environment', '__return_false', 'piaio-settings');

    add_settings_field('piaio_env', 'Environment', function () {
      $opts = self::get_settings();
      ?>
        <label><input type="radio" name="<?php echo esc_attr(self::OPT_KEY); ?>[env]" value="prod" <?php checked($opts['env'],'prod'); ?> /> Production (Mainnet)</label><br>
        <label><input type="radio" name="<?php echo esc_attr(self::OPT_KEY); ?>[env]" value="sandbox" <?php checked($opts['env'],'sandbox'); ?> /> Sandbox (Testnet)</label><br>
        <label><input type="radio" name="<?php echo esc_attr(self::OPT_KEY); ?>[env]" value="auto" <?php checked($opts['env'],'auto'); ?> /> Auto (detect)</label>
        <p class="description">“Auto” sets Sandbox if the URL has <code>?pi_sandbox=1</code> or the referrer is <code>sandbox.minepi.com</code>, otherwise Production.</p>
      <?php
    }, 'piaio-settings', 'piaio_main');

    add_settings_field('piaio_debug', 'Debug logs', function () {
      $opts = self::get_settings();
      ?>
        <label><input type="checkbox" name="<?php echo esc_attr(self::OPT_KEY); ?>[debug]" value="1" <?php checked($opts['debug'],1); ?> /> Enable verbose console logs</label>
      <?php
    }, 'piaio-settings', 'piaio_main');
  }

  public function admin_page() {
    ?>
    <div class="wrap">
      <h1>Pi Auth – Settings</h1>
      <form method="post" action="options.php">
        <?php settings_fields('piaio_group'); do_settings_sections('piaio-settings'); submit_button(); ?>
      </form>

      <h2>Quick Test</h2>
      <ol>
        <li>Open your page inside <strong>Pi Browser</strong>.</li>
        <li>Check console for <code>[PiAIO] sdk:init { sandbox: true|false }</code>.</li>
        <li>Append <code>?pi_sandbox=1</code> to force Sandbox in Auto mode.</li>
      </ol>
    </div>
    <?php
  }

  // ---------- Auth logic ----------
  public function is_authed_user() {
    $uid = get_current_user_id();
    if (!$uid) return false;
    $pi_uid = get_user_meta($uid, 'pi_uid', true);
    if (empty($pi_uid)) return false;
    if (empty($_COOKIE['piaio_pi_authed'])) return false;
    return true;
  }

  public function enqueue() {
    if (!is_singular()) return;
    global $post;
    $content = $post ? $post->post_content : '';
    $has_gate  = $content && has_shortcode($content, 'pi_gate');
    $has_login = $content && (has_shortcode($content, 'pi_login_v2') || has_shortcode($content, 'pi_lock'));
    if (!$has_gate && !$has_login) return;

    $ver = self::VERSION;
    wp_register_script('piaio-js', plugins_url('assets/pi-auth.js', __FILE__), [], $ver, true);

    $opts = self::get_settings();
    $sandbox = null;
    if ($opts['env'] === 'sandbox') $sandbox = true;
    if ($opts['env'] === 'prod')    $sandbox = false;

    wp_localize_script('piaio-js', 'PI_AUTH_CFG', [
      'rest'    => esc_url_raw( rest_url(self::REST_NS . '/' . self::REST_LOGIN) ),
      'nonce'   => wp_create_nonce('wp_rest'),
      'version' => '2.0',
      'sandbox' => $sandbox,
      'debug'   => (bool) $opts['debug'],
      'locks'   => [],
    ]);

    wp_enqueue_script('piaio-js');

    $css = '.piaio-chip{display:inline-flex;gap:.5rem;align-items:center;background:#eee;border-radius:999px;padding:.25rem .5rem;font-size:.875rem}
    .piaio-gate.piaio-locked>.piaio-inner{display:none}
    .piaio-notice{background:#fff3cd;border:1px solid #ffeeba;padding:.75rem;border-radius:.5rem;margin:.5rem 0}
    .piaio-hide{display:none!important}';
    wp_register_style('piaio-inline', false, [], $ver);
    wp_enqueue_style('piaio-inline');
    wp_add_inline_style('piaio-inline', $css);

    wp_add_inline_script('piaio-js', 'window.PIAIO_PREAUTH=' . json_encode($this->is_authed_user()) . ';', 'before');
  }

  public function body_class($classes) {
    $classes[] = $this->is_authed_user() ? 'piaio-user' : 'piaio-guest';
    return $classes;
  }

  public function rest() {
    register_rest_route(self::REST_NS, '/' . self::REST_LOGIN, [
      'methods'  => 'POST',
      'permission_callback' => '__return_true',
      'callback' => [$this, 'rest_login'],
    ]);
  }

  public function rest_login($req) {
    $body = json_decode($req->get_body(), true);
    if (!$body || empty($body['accessToken']) || empty($body['user']) || empty($body['user']['uid']) ) {
      return new WP_REST_Response(['ok'=>false,'error'=>'invalid_payload'], 400);
    }

    $pi_uid  = sanitize_text_field($body['user']['uid']);
    $pi_name = isset($body['user']['username']) ? sanitize_user($body['user']['username']) : ('piuser_' . wp_generate_password(6, false));

    $user_id = $this->find_user_by_pi_uid($pi_uid);
    if (!$user_id) {
      $login = $this->unique_login_from($pi_name);
      $password = wp_generate_password(24, true, true);
      $user_id = wp_insert_user([
        'user_login' => $login,
        'user_pass'  => $password,
        'display_name' => $pi_name,
        'user_nicename'=> sanitize_title($pi_name),
      ]);
      if (is_wp_error($user_id)) {
        return new WP_REST_Response(['ok'=>false,'error'=>'user_create_failed','msg'=>$user_id->get_error_message()], 500);
      }
      update_user_meta($user_id, 'pi_uid', $pi_uid);
    }

    wp_set_current_user($user_id);
    wp_set_auth_cookie($user_id, true);
    do_action('wp_login', get_userdata($user_id)->user_login, get_userdata($user_id));

    setcookie('piaio_pi_authed', '1', time() + DAY_IN_SECONDS, COOKIEPATH, COOKIE_DOMAIN, is_ssl(), true);

    return new WP_REST_Response([
      'ok'=>true,
      'user'=>[
        'id'=>$user_id,
        'login'=>get_userdata($user_id)->user_login,
        'display'=>get_userdata($user_id)->display_name,
      ]
    ], 200);
  }

  private function find_user_by_pi_uid($pi_uid) {
    global $wpdb;
    $uid = $wpdb->get_var($wpdb->prepare("SELECT user_id FROM {$wpdb->usermeta} WHERE meta_key='pi_uid' AND meta_value=%s LIMIT 1", $pi_uid));
    return $uid ? intval($uid) : 0;
  }

  private function unique_login_from($base) {
    $login = $base; $i = 1;
    while (username_exists($login)) { $i++; $login = $base . $i; }
    return $login;
  }

  // ---------- Shortcodes ----------
  public function sc_login($atts, $content='') {
    $label = isset($atts['label']) ? sanitize_text_field($atts['label']) : 'Login with Pi';
    $html  = '<button class="piaio-login" data-rest="'. esc_attr( rest_url(self::REST_NS . '/' . self::REST_LOGIN) ) .'">'. esc_html($label) .'</button>';
    $html .= '<span class="piaio-chip piaio-hide"></span>';
    return $html;
  }

  public function sc_gate($atts, $content='') {
    $atts = shortcode_atts([
      'force'   => 'false',
      'message' => 'Authentication required. Please sign in with Pi to continue.',
    ], $atts, 'pi_gate');
    $force = filter_var($atts['force'], FILTER_VALIDATE_BOOLEAN);

    if (!$force && $this->is_authed_user()) {
      return do_shortcode($content);
    }
    $btn    = do_shortcode('[pi_login_v2 label="Login with Pi"]');
    $notice = '<div class="piaio-notice">'. esc_html($atts['message']) .'</div>';
    return '<div class="piaio-gate piaio-locked"><div class="piaio-inner">'. do_shortcode($content) .'</div>'. $notice . $btn .'</div>';
  }

  public function sc_lock($atts) {
    $sel = isset($atts['sel']) ? trim($atts['sel']) : '';
    if (!$sel) return '';
    $list = array_map('trim', explode(',', $sel));
    $json = wp_json_encode(array_values(array_filter($list)));
    $script = "<script>window.PI_AUTH_CFG=window.PI_AUTH_CFG||{};(PI_AUTH_CFG.locks=PI_AUTH_CFG.locks||[]).push(...$json);</script>";
    $btn  = do_shortcode('[pi_login_v2 label="Login with Pi"]');
    $html = '<div class="piaio-notice piaio-lock-note">Authentication required to view this section.</div>'.$btn;
    return $script . ($this->is_authed_user() ? '' : $html);
  }
}

new PIAIO_SimpleV2();

add_action('wp_logout', function () {
  setcookie('piaio_pi_authed', '', time() - 3600, COOKIEPATH, COOKIE_DOMAIN, is_ssl(), true);
});
