=== Pi Auth – All-in-One (Simple) v2 ===
Contributors: chatgpt
Tags: pi network, authentication, login, gating
Tested up to: 6.5
Stable tag: 2.3.0
License: GPLv2

A tiny Pi Network auth helper for WordPress with content gating and heavy debug.

Shortcodes:
[pi_login_v2] – Renders "Login with Pi" button
[pi_gate] ... [/pi_gate] – Shows inner content after successful Pi auth
[pi_lock sel="#selector1,#selector2"] – Hides arbitrary selectors until Pi auth

Settings:
Admin → Pi Auth. Choose Production/Sandbox/Auto and enable verbose logs.
