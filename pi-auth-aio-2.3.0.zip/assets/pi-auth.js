(function(){
  const cfg = window.PI_AUTH_CFG || {};
  const log = (...a)=>{ if(cfg.debug) console.log("[PiAIO]", ...a); };

  function detectSandbox() {
    if (cfg.sandbox === true) return true;
    if (cfg.sandbox === false) return false;
    try {
      const url = new URL(window.location.href);
      if (url.searchParams.get('pi_sandbox') === '1') return true;
    } catch(_) {}
    if (document.referrer && /sandbox\.minepi\.com/i.test(document.referrer)) return true;
    return false;
  }

  const sandbox = detectSandbox();
  log("sdk:init", {sandbox});

  async function initPi() {
    if (!window.Pi || !window.Pi.init) {
      log("Pi SDK not found (not in Pi Browser).");
      return;
    }
    try {
      await window.Pi.init({ version: cfg.version || "2.0", sandbox });
      log("status: SDK ready");
    } catch (e) {
      console.error("[PiAIO] Pi SDK failed to init", e);
    }
  }
  initPi();

  function revealGates() {
    document.querySelectorAll(".piaio-gate.piaio-locked").forEach(el => el.classList.remove("piaio-locked"));
    (cfg.locks || []).forEach(sel => {
      try { document.querySelectorAll(sel).forEach(n => n.classList.remove("piaio-hide")); } catch(_){}
    });
  }

  async function handleLogin(btn) {
    if (!window.Pi || !Pi.authenticate) {
      alert("Open in Pi Browser to authenticate.");
      return;
    }
    try {
      const auth = await Pi.authenticate(['username'], function onIncomplete(){});
      log("auth_ok", auth);
      await sendToServer(auth);
      const chip = btn.parentElement.querySelector(".piaio-chip");
      if (chip) {
        const name = auth?.user?.username ? "@"+auth.user.username : "Pi user";
        chip.textContent = "Logged in as " + name;
        chip.classList.remove("piaio-hide");
      }
      revealGates();
      document.querySelectorAll(".piaio-login").forEach(b=>b.remove());
    } catch (e) {
      console.error("[PiAIO] auth_error", e);
      alert("Authentication failed.");
    }
  }

  async function sendToServer(auth) {
    const res = await fetch(cfg.rest, {
      method: 'POST',
      headers: {'Content-Type':'application/json','X-WP-Nonce': cfg.nonce || ''},
      body: JSON.stringify({accessToken: auth.accessToken, user: auth.user})
    });
    if (!res.ok) throw new Error("Server " + res.status);
    return res.json();
  }

  function boot() {
    document.querySelectorAll(".piaio-login").forEach(btn => {
      if (btn.dataset.piaioBound) return;
      btn.dataset.piaioBound = "1";
      btn.addEventListener("click", () => handleLogin(btn));
    });

    if (window.PIAIO_PREAUTH) {
      revealGates();
      document.querySelectorAll(".piaio-chip").forEach(c=>{
        c.textContent = "Authenticated";
        c.classList.remove("piaio-hide");
      });
    } else {
      (cfg.locks || []).forEach(sel => {
        try { document.querySelectorAll(sel).forEach(n => n.classList.add("piaio-hide")); } catch(_){}
      });
    }
  }

  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", boot);
  else boot();
})();